<?php

include 'lib/Database.php';
include_once 'lib/Session.php';


class Users{


  // Db Property
  private $db;

  // Db __construct Method
  public function __construct(){
    $this->db = new Database();
  }

  // Date formate Method
   public function formatDate($date){
     // date_default_timezone_set('Asia/Dhaka');
      $strtime = strtotime($date);
    return date('Y-m-d H:i:s', $strtime);
   }
   public function updateDate($date){
    // date_default_timezone_set('Asia/Dhaka');
     $strtime = strtotime($date);
   return date('Y-m-d H:i:s', $strtime);
  }


  // Check Exist Email Address Method
  public function checkExistEmail($email){
    $sql = "SELECT email from  tbl_users WHERE email = :email";
    $stmt = $this->db->pdo->prepare($sql);
    $stmt->bindValue(':email', $email);
     $stmt->execute();
    if ($stmt->rowCount()> 0) {
      return true;
    }else{
      return false;
    }
  }



  // User Registration Method
  public function userRegistration($data){
    $name = $data['name'];
    $username = $data['username'];
    $email = $data['email'];
    $mobile = $data['mobile'];
    $roleid = $data['roleid'];
    $password = $data['password'];

    $checkEmail = $this->checkExistEmail($email);

    if ($name == "" || $username == "" || $email == "" || $mobile == "" || $password == "") {
      $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
<strong>Error !</strong> Please, User Registration field must not be Empty !</div>';
        return $msg;
    }elseif (strlen($username) < 3) {
      $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
<strong>Error !</strong> Username is too short, at least 3 Characters !</div>';
        return $msg;
    }elseif (filter_var($mobile,FILTER_SANITIZE_NUMBER_INT) == FALSE) {
      $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
<strong>Error !</strong> Enter only Number Characters for Mobile number field !</div>';
        return $msg;

    }elseif(strlen($password) < 5) {
      $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
<strong>Error !</strong> Password at least 6 Characters !</div>';
        return $msg;
    }elseif(!preg_match("#[0-9]+#",$password)) {
      $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
<strong>Error !</strong> Your Password Must Contain At Least 1 Number !</div>';
        return $msg;
    }elseif(!preg_match("#[a-z]+#",$password)) {
      $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
<strong>Error !</strong> Your Password Must Contain At Least 1 Number !</div>';
        return $msg;
    }elseif (filter_var($email, FILTER_VALIDATE_EMAIL === FALSE)) {
      $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
<strong>Error !</strong> Invalid email address !</div>';
        return $msg;
    }elseif ($checkEmail == TRUE) {
      $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
<strong>Error !</strong> Email already Exists, please try another Email... !</div>';
        return $msg;
    }else{

      $sql = "INSERT INTO tbl_users(name, username, email, password, mobile, roleid) VALUES(:name, :username, :email, :password, :mobile, :roleid)";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->bindValue(':name', $name);
      $stmt->bindValue(':username', $username);
      $stmt->bindValue(':email', $email);
      $stmt->bindValue(':password', SHA1($password));
      $stmt->bindValue(':mobile', $mobile);
      $stmt->bindValue(':roleid', $roleid);
      $result = $stmt->execute();
      if ($result) {
        $msg = '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <strong>Success !</strong> Wow, you have Registered Successfully !</div>';
          return $msg;
      }else{
        $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <strong>Error !</strong> Something went Wrong !</div>';
          return $msg;
      }



    }





  }
  // Add New User By Admin
  public function addNewUserByAdmin($data){
    $name = $data['name'];
    $username = $data['username'];
    $email = $data['email'];
    $mobile = $data['mobile'];
    $roleid = $data['roleid'];
    $password = $data['password'];

    $checkEmail = $this->checkExistEmail($email);

    if ($name == "" || $username == "" || $email == "" || $mobile == "" || $password == "") {
      $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
<strong>Error !</strong> Input fields must not be Empty !</div>';
        return $msg;
    }elseif (strlen($username) < 3) {
      $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
<strong>Error !</strong> Username is too short, at least 3 Characters !</div>';
        return $msg;
    }elseif (filter_var($mobile,FILTER_SANITIZE_NUMBER_INT) == FALSE) {
      $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
<strong>Error !</strong> Enter only Number Characters for Mobile number field !</div>';
        return $msg;

    }elseif(strlen($password) < 5) {
      $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
<strong>Error !</strong> Password at least 6 Characters !</div>';
        return $msg;
    }elseif(!preg_match("#[0-9]+#",$password)) {
      $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
<strong>Error !</strong> Your Password Must Contain At Least 1 Number !</div>';
        return $msg;
    }elseif(!preg_match("#[a-z]+#",$password)) {
      $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
<strong>Error !</strong> Your Password Must Contain At Least 1 Number !</div>';
        return $msg;
    }elseif (filter_var($email, FILTER_VALIDATE_EMAIL === FALSE)) {
      $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
<strong>Error !</strong> Invalid email address !</div>';
        return $msg;
    }elseif ($checkEmail == TRUE) {
      $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
<strong>Error !</strong> Email already Exists, please try another Email... !</div>';
        return $msg;
    }else{

      $sql = "INSERT INTO tbl_users(name, username, email, password, mobile, roleid) VALUES(:name, :username, :email, :password, :mobile, :roleid)";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->bindValue(':name', $name);
      $stmt->bindValue(':username', $username);
      $stmt->bindValue(':email', $email);
      $stmt->bindValue(':password', SHA1($password));
      $stmt->bindValue(':mobile', $mobile);
      $stmt->bindValue(':roleid', $roleid);
      $result = $stmt->execute();
      if ($result) {
        $msg = '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <strong>Success !</strong> Wow, you have Registered Successfully !</div>';
          return $msg;
      }else{
        $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <strong>Error !</strong> Something went Wrong !</div>';
          return $msg;
      }



    }





  }



  // Select All User Method
  public function selectAllUserData(){
    $sql = "SELECT * FROM tbl_users ORDER BY id DESC";
    $stmt = $this->db->pdo->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_OBJ);
  }


  // User login Autho Method
  public function userLoginAutho($email, $password){
    $password = SHA1($password);
    $sql = "SELECT * FROM tbl_users WHERE email = :email and password = :password LIMIT 1";
    $stmt = $this->db->pdo->prepare($sql);
    $stmt->bindValue(':email', $email);
    $stmt->bindValue(':password', $password);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_OBJ);
  }
  // Check User Account Satatus
  public function CheckActiveUser($email){
    $sql = "SELECT * FROM tbl_users WHERE email = :email and isActive = :isActive LIMIT 1";
    $stmt = $this->db->pdo->prepare($sql);
    $stmt->bindValue(':email', $email);
    $stmt->bindValue(':isActive', 1);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_OBJ);
  }




    // User Login Authotication Method
    public function userLoginAuthotication($data){
      $email = $data['email'];
      $password = $data['password'];


      $checkEmail = $this->checkExistEmail($email);

      if ($email == "" || $password == "" ) {
        $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <strong>Error !</strong> Email or Password not be Empty !</div>';
          return $msg;

      }elseif (filter_var($email, FILTER_VALIDATE_EMAIL === FALSE)) {
        $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <strong>Error !</strong> Invalid email address !</div>';
          return $msg;
      }elseif ($checkEmail == FALSE) {
        $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <strong>Error !</strong> Email did not Found, use Register email or password please !</div>';
          return $msg;
      }else{


        $logResult = $this->userLoginAutho($email, $password);
        $chkActive = $this->CheckActiveUser($email);

        if ($chkActive == TRUE) {
          $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Sorry, Your account is Diactivated, Contact with Admin !</div>';
            return $msg;
        }elseif ($logResult) {

          Session::init();
          Session::set('login', TRUE);
          Session::set('id', $logResult->id);
          Session::set('roleid', $logResult->roleid);
          Session::set('name', $logResult->name);
          Session::set('email', $logResult->email);
          Session::set('username', $logResult->username);
          Session::set('logMsg', '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Success !</strong> You are Logged In Successfully !</div>');
          echo "<script>location.href='index.php';</script>";

        }else{
          $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Email or Password did not Matched !</div>';
            return $msg;
        }

      }


    }



    // Get Single User Information By Id Method
    public function getUserInfoById($userid){
      $sql = "SELECT * FROM tbl_users WHERE id = :id LIMIT 1";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->bindValue(':id', $userid);
      $stmt->execute();
      $result = $stmt->fetch(PDO::FETCH_OBJ);
      if ($result) {
        return $result;
      }else{
        return false;
      }


    }



  //
  //   Get Single User Information By Id Method
    public function updateUserByIdInfo($userid, $data){
      $name = $data['name'];
      $username = $data['username'];
      $email = $data['email'];
      $mobile = $data['mobile'];
      $roleid = $data['roleid'];



      if ($name == "" || $username == ""|| $email == "" || $mobile == ""  ) {
        $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <strong>Error !</strong> Input Fields must not be Empty !</div>';
          return $msg;
        }elseif (strlen($username) < 3) {
          $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Username is too short, at least 3 Characters !</div>';
            return $msg;
        }elseif (filter_var($mobile,FILTER_SANITIZE_NUMBER_INT) == FALSE) {
          $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Enter only Number Characters for Mobile number field !</div>';
            return $msg;


      }elseif (filter_var($email, FILTER_VALIDATE_EMAIL === FALSE)) {
        $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <strong>Error !</strong> Invalid email address !</div>';
          return $msg;
      }else{

        $sql = "UPDATE tbl_users SET
          name = :name,
          username = :username,
          email = :email,
          mobile = :mobile,
          roleid = :roleid
          WHERE id = :id";
          $stmt= $this->db->pdo->prepare($sql);
          $stmt->bindValue(':name', $name);
          $stmt->bindValue(':username', $username);
          $stmt->bindValue(':email', $email);
          $stmt->bindValue(':mobile', $mobile);
          $stmt->bindValue(':roleid', $roleid);
          $stmt->bindValue(':id', $userid);
        $result =   $stmt->execute();

        if ($result) {
          echo "<script>location.href='index01.php';</script>";
          Session::set('msg', '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          <strong>Success !</strong> Wow, Your Information updated Successfully !</div>');



        }else{
          echo "<script>location.href='index.php';</script>";
          Session::set('msg', '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Data not inserted !</div>');


        }


      }


    }




    // Delete User by Id Method
    public function deleteUserById($remove){
      $sql = "DELETE FROM tbl_users WHERE id = :id ";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->bindValue(':id', $remove);
        $result =$stmt->execute();
        if ($result) {
          $msg = '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Success !</strong> User account Deleted Successfully !</div>';
            return $msg;
        }else{
          $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Data not Deleted !</div>';
            return $msg;
        }
    }

    // User Deactivated By Admin
    public function userDeactiveByAdmin($deactive){
      $sql = "UPDATE tbl_users SET

       isActive=:isActive
       WHERE id = :id";

       $stmt = $this->db->pdo->prepare($sql);
       $stmt->bindValue(':isActive', 1);
       $stmt->bindValue(':id', $deactive);
       $result =   $stmt->execute();
        if ($result) {
          echo "<script>location.href='index01.php';</script>";
          Session::set('msg', '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          <strong>Success !</strong> User account Diactivated Successfully !</div>');

        }else{
          echo "<script>location.href='index01.php';</script>";
          Session::set('msg', '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Data not Diactivated !</div>');

            return $msg;
        }
    }


    // User Deactivated By Admin
    public function userActiveByAdmin($active){
      $sql = "UPDATE tbl_users SET
       isActive=:isActive
       WHERE id = :id";

       $stmt = $this->db->pdo->prepare($sql);
       $stmt->bindValue(':isActive', 0);
       $stmt->bindValue(':id', $active);
       $result =   $stmt->execute();
        if ($result) {
          echo "<script>location.href='index01.php';</script>";
          Session::set('msg', '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          <strong>Success !</strong> User account activated Successfully !</div>');
        }else{
          echo "<script>location.href='index01.php';</script>";
          Session::set('msg', '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Data not activated !</div>');
        }
    }




    // Check Old password method
    public function CheckOldPassword($userid, $old_pass){
      $old_pass = SHA1($old_pass);
      $sql = "SELECT password FROM tbl_users WHERE password = :password AND id =:id";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->bindValue(':password', $old_pass);
      $stmt->bindValue(':id', $userid);
      $stmt->execute();
      if ($stmt->rowCount() > 0) {
        return true;
      }else{
        return false;
      }
    }



    // Change User pass By Id
    public  function changePasswordBysingelUserId($userid, $data){

      $old_pass = $data['old_password'];
      $new_pass = $data['new_password'];


      if ($old_pass == "" || $new_pass == "" ) {
        $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <strong>Error !</strong> Password field must not be Empty !</div>';
          return $msg;
      }elseif (strlen($new_pass) < 6) {
        $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <strong>Error !</strong> New password must be at least 6 character !</div>';
          return $msg;
       }

         $oldPass = $this->CheckOldPassword($userid, $old_pass);
         if ($oldPass == FALSE) {
           $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
     <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
     <strong>Error !</strong> Old password did not Matched !</div>';
             return $msg;
         }else{
           $new_pass = SHA1($new_pass);
           $sql = "UPDATE tbl_users SET

            password=:password
            WHERE id = :id";

            $stmt = $this->db->pdo->prepare($sql);
            $stmt->bindValue(':password', $new_pass);
            $stmt->bindValue(':id', $userid);
            $result =   $stmt->execute();

          if ($result) {
            echo "<script>location.href='index.php';</script>";
            Session::set('msg', '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <strong>Success !</strong> Great news, Password Changed successfully !</div>');

          }else{
            $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
      <strong>Error !</strong> Password did not changed !</div>';
              return $msg;
          }

         }



    }

    public function addLatestnews($data){
      $post_title = $data['post_title'];
      $post_desc = $data['post_desc'];
      $categoryid = $data['categoryid'];
      if ($post_title == "" || $post_desc == "" || $categoryid == "") {
        $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Input fields must not be Empty !</div>';
          return $msg;
    }else{
    
      $sql = "INSERT INTO tbl_posts(post_title, post_desc, categoryid) VALUES(:post_title, :post_desc, :categoryid)";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->bindValue(':post_title', $post_title);
      $stmt->bindValue(':post_desc', $post_desc);
      $stmt->bindValue(':categoryid', $categoryid);
      $result = $stmt->execute();
      if ($result) {
        $msg = '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Success !</strong> Wow, you have added Successfully !</div>';
          return $msg;
      }else{
        $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Something went Wrong !</div>';
          return $msg;
      }
    
    
    
    
    
    
    
    }
    }
    public function selectAllArticleData(){
      $sql = "SELECT * FROM tbl_posts ORDER BY post_id DESC";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->execute();
      return $stmt->fetchAll(PDO::FETCH_OBJ);
    }

    public function deleteArticleById($remove){
      $sql = "DELETE FROM tbl_posts WHERE post_id = :post_id";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->bindValue(':post_id', $remove);
        $result =$stmt->execute();
        if ($result) {
          $msg = '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Success !</strong> Article Deleted Successfully !</div>';
            return $msg;
        }else{
          $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Data not Deleted !</div>';
            return $msg;
        }
    }

    public function getArticleInfoById($userid){
      $sql = "SELECT * FROM tbl_posts WHERE post_id = :post_id LIMIT 1";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->bindValue(':post_id', $userid);
      $stmt->execute();
      $result = $stmt->fetch(PDO::FETCH_OBJ);
      if ($result) {
        return $result;
      }else{
        return false;
      }


    }
    public function updateArticleByIdInfo($userid, $data){
      $post_title = $data['post_title'];
      $post_desc = $data['post_desc'];
      $categoryid = $data['categoryid'];



      if ($post_title == "" || $post_desc == ""|| $categoryid == "") {
        $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <strong>Error !</strong> Input Fields must not be Empty !</div>';
          return $msg;
        }else{

        $sql = "UPDATE tbl_posts SET
          post_title = :post_title,
          post_desc = :post_desc,
          categoryid = :categoryid
          WHERE post_id = :post_id";
          $stmt= $this->db->pdo->prepare($sql);
          $stmt->bindValue(':post_id', $userid);
          $stmt->bindValue(':post_title', $post_title);
          $stmt->bindValue(':post_desc', $post_desc);
          $stmt->bindValue(':categoryid', $categoryid);
          
          $result =  $stmt->execute();

        if ($result) {
          echo "<script>location.href='recycleInformationsystem.php';</script>";
          Session::set('msg', '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          <strong>Success !</strong> Wow, Your Information updated Successfully !</div>');



        }else{
          echo "<script>location.href='updateArticle.php';</script>";
          Session::set('msg', '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Data not inserted !</div>');


        }


      }


    }
    //rewardsystem.php
    public function selectAllRewardData(){
      $sql = "SELECT * FROM tbl_reward ORDER BY post_id DESC";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->execute();
      return $stmt->fetchAll(PDO::FETCH_OBJ);
    }
    

    public function addReward($data){
      $post_name = $data['post_name'];
      $post_quantity = $data['post_quantity'];
      $post_point = $data['post_point'];
      
//picture coding
$picture_name=$_FILES['post_image']['name'];
$picture_type=$_FILES['post_image']['type'];
$picture_tmp_name=$_FILES['post_image']['tmp_name'];
$picture_size=$_FILES['post_image']['size'];

if($picture_type=="image/jpeg" || $picture_type=="image/jpg" || $picture_type=="image/png" || $picture_type=="image/gif")
{
	if($picture_size<=50000000)
	
		$pic_name=$picture_name;
		move_uploaded_file($picture_tmp_name,"product_images/".$pic_name);
    $post_image = $_FILES['post_image']['name'];
    
      $sql = "INSERT INTO tbl_reward(post_name, post_image, post_quantity, post_point) VALUES(:post_name, :post_image, :post_quantity, :post_point)";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->bindValue(':post_name', $post_name);
      $stmt->bindValue(':post_image', $post_image);
      $stmt->bindValue(':post_quantity', $post_quantity);
      $stmt->bindValue(':post_point', $post_point);
      $result = $stmt->execute();
      if ($result) {
        $msg = '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Success !</strong> Wow, you have added Successfully !</div>';
          return $msg;
      }else{
        $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Something went Wrong !</div>';
          return $msg;
      }
    
    
    
    
    
    
    
    }
    }

    public function deleteRewardById($remove){
      $sql = "DELETE FROM tbl_reward WHERE post_id = :post_id";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->bindValue(':post_id', $remove);
        $result =$stmt->execute();
        if ($result) {
          $msg = '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Success !</strong> Reward Deleted Successfully !</div>';
            return $msg;
        }else{
          $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Data not Deleted !</div>';
            return $msg;
        }
    }

    public function getRewardInfoById($userid){
      $sql = "SELECT * FROM tbl_reward WHERE post_id = :post_id LIMIT 1";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->bindValue(':post_id', $userid);
      $stmt->execute();
      $result = $stmt->fetch(PDO::FETCH_OBJ);
      if ($result) {
        return $result;
      }else{
        return false;
      }


    }
    

    public function updateRewardByIdInfo($userid, $data){
      $post_name = $data['post_name'];
      $post_quantity = $data['post_quantity'];
      $post_point = $data['post_point'];
      
//picture coding
$picture_name=$_FILES['post_image']['name'];
$picture_type=$_FILES['post_image']['type'];
$picture_tmp_name=$_FILES['post_image']['tmp_name'];
$picture_size=$_FILES['post_image']['size'];

if($picture_type=="image/jpeg" || $picture_type=="image/jpg" || $picture_type=="image/png" || $picture_type=="image/gif")
{
	if($picture_size<=50000000)
	
		$pic_name=$picture_name;
		move_uploaded_file($picture_tmp_name,"product_images/".$pic_name);
    $post_image = $_FILES['post_image']['name'];

        $sql = "UPDATE tbl_reward SET
          post_name = :post_name,
          post_image = :post_image,
          post_quantity = :post_quantity,
          post_point = :post_point
          WHERE post_id = :post_id";

          $stmt= $this->db->pdo->prepare($sql);
          $stmt->bindValue(':post_id', $userid);
          $stmt->bindValue(':post_name', $post_name);
          $stmt->bindValue(':post_image', $post_image);
          $stmt->bindValue(':post_quantity', $post_quantity);
          $stmt->bindValue(':post_point', $post_point);
          
          $result =  $stmt->execute();

        if ($result) {
          echo "<script>location.href='rewardsystem.php';</script>";
          Session::set('msg', '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          <strong>Success !</strong> Wow, Reward Information updated Successfully !</div>');



        }else{
          echo "<script>location.href='updateReward.php';</script>";
          Session::set('msg', '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Data not inserted !</div>');


        }


      }
      else{
        $sql = "UPDATE tbl_reward SET
          post_name = :post_name,
          post_quantity = :post_quantity,
          post_point = :post_point
          WHERE post_id = :post_id";

          $stmt= $this->db->pdo->prepare($sql);
          $stmt->bindValue(':post_id', $userid);
          $stmt->bindValue(':post_name', $post_name);
          $stmt->bindValue(':post_quantity', $post_quantity);
          $stmt->bindValue(':post_point', $post_point);
          
          $result =  $stmt->execute();

        if ($result) {
          echo "<script>location.href='rewardsystem.php';</script>";
          Session::set('msg', '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          <strong>Success !</strong> Wow, Reward Information updated Successfully !</div>');



        }else{
          echo "<script>location.href='updateReward.php';</script>";
          Session::set('msg', '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Data not inserted !</div>');


        }
      }


    }

        // Reward Deactivated By Admin
        public function rewardDeactiveByAdmin($deactive){
          $sql = "UPDATE tbl_reward SET
    
           isActive=:isActive
           WHERE post_id = :post_id";
    
           $stmt = $this->db->pdo->prepare($sql);
           $stmt->bindValue(':isActive', 1);
           $stmt->bindValue(':post_id', $deactive);
           $result =   $stmt->execute();
            if ($result) {
              echo "<script>location.href='rewardsystem.php';</script>";
              Session::set('msg', '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <strong>Success !</strong> Reward Diactivated Successfully !</div>');
    
            }else{
              echo "<script>location.href='rewardsystem.php';</script>";
              Session::set('msg', '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong>Error !</strong> Reward not Diactivated !</div>');
    
                return $msg;
            }
        }
    
    
        // Reward Activated By Admin
        public function rewardActiveByAdmin($active){
          $sql = "UPDATE tbl_reward SET
           isActive=:isActive
           WHERE post_id = :post_id";
    
           $stmt = $this->db->pdo->prepare($sql);
           $stmt->bindValue(':isActive', 0);
           $stmt->bindValue(':post_id', $active);
           $result =   $stmt->execute();
            if ($result) {
              echo "<script>location.href='rewardsystem.php';</script>";
              Session::set('msg', '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <strong>Success !</strong> Reward activated Successfully !</div>');
            }else{
              echo "<script>location.href='rewardsystem.php';</script>";
              Session::set('msg', '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong>Error !</strong> Reward not activated !</div>');
            }
        }

        //pointsystem-addRules
        public function addRules($data){
          $name = $data['name'];
          $details = $data['details'];
          $points = $data['points'];
          if ($name == "" || $details == "" || $points == "") {
            $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong>Error !</strong> Input fields must not be Empty !</div>';
              return $msg;
        }else{
        
          $sql = "INSERT INTO tbl_rules(name, details, points) VALUES(:name, :details, :points)";
          $stmt = $this->db->pdo->prepare($sql);
          $stmt->bindValue(':name', $name);
          $stmt->bindValue(':details', $details);
          $stmt->bindValue(':points', $points);
          $result = $stmt->execute();
          if ($result) {
            $msg = '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong>Success !</strong> Wow, you have added Successfully !</div>';
              return $msg;
          }else{
            $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong>Error !</strong> Something went Wrong !</div>';
              return $msg;
          }
        }
      }
      //selectRulesData
      public function selectAllRulesData(){
        $sql = "SELECT * FROM tbl_rules ORDER BY id DESC";
        $stmt = $this->db->pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_OBJ);
      }
      //deleteRules
      public function deleteRulesById($remove){
        $sql = "DELETE FROM tbl_rules WHERE id = :id";
        $stmt = $this->db->pdo->prepare($sql);
        $stmt->bindValue(':id', $remove);
          $result =$stmt->execute();
          if ($result) {
            $msg = '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
      <strong>Success !</strong> Rule Deleted Successfully !</div>';
              return $msg;
          }else{
            $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
      <strong>Error !</strong> Data not Deleted !</div>';
              return $msg;
          }
      }
      //getRules
      public function getRulesInfoById($userid){
        $sql = "SELECT * FROM tbl_rules WHERE id = :id LIMIT 1";
        $stmt = $this->db->pdo->prepare($sql);
        $stmt->bindValue(':id', $userid);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_OBJ);
        if ($result) {
          return $result;
        }else{
          return false;
        }
  
  
      }
      //updateRules
      public function updateRulesByIdInfo($userid, $data){
        $name = $data['name'];
        $details = $data['details'];
        $points = $data['points'];
  
  
  
        if ($name == "" || $details == ""|| $points == "") {
          $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Input Fields must not be Empty !</div>';
            return $msg;
          }else{
  
            $sql = "UPDATE tbl_rules SET
            name = :name,
            details = :details,
            points = :points
            WHERE id = :id";

            $stmt = $this->db->pdo->prepare($sql);
            $stmt->bindValue(':id', $userid);
            $stmt->bindValue(':name', $name);
            $stmt->bindValue(':details', $details);
            $stmt->bindValue(':points', $points);
            
            $result = $stmt->execute();
          if ($result) {
            echo "<script>location.href='rulessystem.php';</script>";
            Session::set('msg', '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <strong>Success !</strong> Wow, Your Information updated Successfully !</div>');
  
  
  
          }else{
            echo "<script>location.href='updateRules.php';</script>";
            Session::set('msg', '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
      <strong>Error !</strong> Data not inserted !</div>');
  
  
          }
  
  
        }
  
  
      }

      //tasksystem-addTask
      public function addTask($data){
        $name = $data['name'];
        $details = $data['details'];
        $points = $data['points'];
        if ($name == "" || $details == "" || $points == "") {
          $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
      <strong>Error !</strong> Input fields must not be Empty !</div>';
            return $msg;
      }else{
      
        $sql = "INSERT INTO tbl_task(name, details, points) VALUES(:name, :details, :points)";
        $stmt = $this->db->pdo->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->bindValue(':details', $details);
        $stmt->bindValue(':points', $points);
        $result = $stmt->execute();
        if ($result) {
          $msg = '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
      <strong>Success !</strong> Wow, you have added Successfully !</div>';
            return $msg;
        }else{
          $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
      <strong>Error !</strong> Something went Wrong !</div>';
            return $msg;
        }
      }
    }
    //selectTaskData
    public function selectAllTaskData(){
      $sql = "SELECT * FROM tbl_task ORDER BY id DESC";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->execute();
      return $stmt->fetchAll(PDO::FETCH_OBJ);
    }
    //deleteTask
    public function deleteTaskById($remove){
      $sql = "DELETE FROM tbl_task WHERE id = :id";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->bindValue(':id', $remove);
        $result =$stmt->execute();
        if ($result) {
          $msg = '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Success !</strong> Task Deleted Successfully !</div>';
            return $msg;
        }else{
          $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Data not Deleted !</div>';
            return $msg;
        }
    }
          //getTask
          public function getTaskInfoById($userid){
            $sql = "SELECT * FROM tbl_task WHERE id = :id LIMIT 1";
            $stmt = $this->db->pdo->prepare($sql);
            $stmt->bindValue(':id', $userid);
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_OBJ);
            if ($result) {
              return $result;
            }else{
              return false;
            }
      
      
          }
          //updateTask
          public function updateTaskByIdInfo($userid, $data){
            $name = $data['name'];
            $details = $data['details'];
            $points = $data['points'];
      
      
      
            if ($name == "" || $details == ""|| $points == "") {
              $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong>Error !</strong> Input Fields must not be Empty !</div>';
                return $msg;
              }else{
      
                $sql = "UPDATE tbl_task SET
                name = :name,
                details = :details,
                points = :points
                WHERE id = :id";

                $stmt = $this->db->pdo->prepare($sql);
                $stmt->bindValue(':id', $userid);
                $stmt->bindValue(':name', $name);
                $stmt->bindValue(':details', $details);
                $stmt->bindValue(':points', $points);
                
                $result = $stmt->execute();
              if ($result) {
                echo "<script>location.href='tasksystem.php';</script>";
                Session::set('msg', '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Success !</strong> Wow, Your Information updated Successfully !</div>');
      
      
      
              }else{
                echo "<script>location.href='updateTask.php';</script>";
                Session::set('msg', '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          <strong>Error !</strong> Data not inserted !</div>');
      
      
              }
      
      
            }
      
      
          }
          //Minestone system - add Minestone
          public function addMinestone($data){
            $name = $data['name'];
            $details = $data['details'];
            $points = $data['points'];
            if ($name == "" || $details == "" || $points == "") {
              $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          <strong>Error !</strong> Input fields must not be Empty !</div>';
                return $msg;
          }else{
          
            $sql = "INSERT INTO tbl_minestone(name, details, points) VALUES(:name, :details, :points)";
            $stmt = $this->db->pdo->prepare($sql);
            $stmt->bindValue(':name', $name);
            $stmt->bindValue(':details', $details);
            $stmt->bindValue(':points', $points);
            $result = $stmt->execute();
            if ($result) {
              $msg = '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          <strong>Success !</strong> Wow, you have added Successfully !</div>';
                return $msg;
            }else{
              $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          <strong>Error !</strong> Something went Wrong !</div>';
                return $msg;
            }
          }
        }
         //selectMinestoneData
    public function selectAllMinestoneData(){
      $sql = "SELECT * FROM tbl_minestone ORDER BY id DESC";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->execute();
      return $stmt->fetchAll(PDO::FETCH_OBJ);
    }
    //deleteTask
    public function deleteMinestoneById($remove){
      $sql = "DELETE FROM tbl_minestone WHERE id = :id";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->bindValue(':id', $remove);
        $result =$stmt->execute();
        if ($result) {
          $msg = '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Success !</strong> Minestone Deleted Successfully !</div>';
            return $msg;
        }else{
          $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Data not Deleted !</div>';
            return $msg;
        }
    }
          //getTask
          public function getMinestoneInfoById($userid){
            $sql = "SELECT * FROM tbl_minestone WHERE id = :id LIMIT 1";
            $stmt = $this->db->pdo->prepare($sql);
            $stmt->bindValue(':id', $userid);
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_OBJ);
            if ($result) {
              return $result;
            }else{
              return false;
            }
      
      
          }
          //updateTask
          public function updateMinestoneByIdInfo($userid, $data){
            $name = $data['name'];
            $details = $data['details'];
            $points = $data['points'];
      
      
      
            if ($name == "" || $details == ""|| $points == "") {
              $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong>Error !</strong> Input Fields must not be Empty !</div>';
                return $msg;
              }else{
      
                $sql = "UPDATE tbl_minestone SET
                name = :name,
                details = :details,
                points = :points
                WHERE id = :id";
                $stmt = $this->db->pdo->prepare($sql);
                $stmt->bindValue(':id', $userid);
                $stmt->bindValue(':name', $name);
                $stmt->bindValue(':details', $details);
                $stmt->bindValue(':points', $points);
                
                $result = $stmt->execute();
              if ($result) {
                echo "<script>location.href='minestonesystem.php';</script>";
                Session::set('msg', '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Success !</strong> Wow, Your Information updated Successfully !</div>');
      
      
      
              }else{
                echo "<script>location.href='updateMinestone.php';</script>";
                Session::set('msg', '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          <strong>Error !</strong> Data not inserted !</div>');
      
      
              }
      
      
            }
      
      
          }

           //managerCompany.php
    public function selectAllCompanyData(){
      $sql = "SELECT * FROM tbl_company ORDER BY id DESC";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->execute();
      return $stmt->fetchAll(PDO::FETCH_OBJ);
    }

    public function addCompany($data){
      $name = $data['name'];
      $email = $data['email'];
      $mobile = $data['mobile'];
      $address = $data['address'];
    
      $sql = "INSERT INTO tbl_company(name, email, mobile, address) VALUES(:name, :email, :mobile, :address)";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->bindValue(':name', $name);
      $stmt->bindValue(':email', $email);
      $stmt->bindValue(':mobile', $mobile);
      $stmt->bindValue(':address', $address);
      $result = $stmt->execute();
      if ($result) {
        $msg = '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Success !</strong> Wow, you have added Successfully !</div>';
          return $msg;
      }else{
        $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Something went Wrong !</div>';
          return $msg;
      }
    
    
    
    
    
    
    
    }
    

    public function deleteCompanyById($remove){
      $sql = "DELETE FROM tbl_company WHERE id = :id";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->bindValue(':id', $remove);
        $result =$stmt->execute();
        if ($result) {
          $msg = '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Success !</strong> Company Deleted Successfully !</div>';
            return $msg;
        }else{
          $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Data not Deleted !</div>';
            return $msg;
        }
    }

    public function getCompanyInfoById($userid){
      $sql = "SELECT * FROM tbl_company WHERE id = :id LIMIT 1";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->bindValue(':id', $userid);
      $stmt->execute();
      $result = $stmt->fetch(PDO::FETCH_OBJ);
      if ($result) {
        return $result;
      }else{
        return false;
      }


    }

    public function updateCompanyByIdInfo($userid, $data){
      $name = $data['name'];
      $email = $data['email'];
      $mobile = $data['mobile'];
      $address = $data['address'];

        $sql = "UPDATE tbl_company SET
          name = :name,
          email = :email,
          mobile = :mobile,
          address = :address
          WHERE id = :id";

          $stmt= $this->db->pdo->prepare($sql);
          $stmt->bindValue(':id', $userid);
          $stmt->bindValue(':name', $name);
          $stmt->bindValue(':email', $email);
          $stmt->bindValue(':mobile', $mobile);
          $stmt->bindValue(':address', $address);
          
          $result =  $stmt->execute();

        if ($result) {
          echo "<script>location.href='managerCompany.php';</script>";
          Session::set('msg', '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          <strong>Success !</strong> Wow, Company Information updated Successfully !</div>');



        }else{
          echo "<script>location.href='updateCompany.php';</script>";
          Session::set('msg', '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Data not inserted !</div>');


        }


      }


    

        // Company Deactivated By Admin
        public function companyDeactiveByAdmin($deactive){
          $sql = "UPDATE tbl_company SET
    
           isActive=:isActive
           WHERE id = :id";
    
           $stmt = $this->db->pdo->prepare($sql);
           $stmt->bindValue(':isActive', 1);
           $stmt->bindValue(':id', $deactive);
           $result =   $stmt->execute();
            if ($result) {
              echo "<script>location.href='managerCompany.php';</script>";
              Session::set('msg', '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <strong>Success !</strong> Company Diactivated Successfully !</div>');
    
            }else{
              echo "<script>location.href='managerCompany.php';</script>";
              Session::set('msg', '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong>Error !</strong> Company not Diactivated !</div>');
    
                return $msg;
            }
        }
    
    
        // Reward Activated By Admin
        public function companyActiveByAdmin($active){
          $sql = "UPDATE tbl_company SET
           isActive=:isActive
           WHERE id = :id";
    
           $stmt = $this->db->pdo->prepare($sql);
           $stmt->bindValue(':isActive', 0);
           $stmt->bindValue(':id', $active);
           $result =   $stmt->execute();
            if ($result) {
              echo "<script>location.href='managerCompany.php';</script>";
              Session::set('msg', '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <strong>Success !</strong> Company activated Successfully !</div>');
            }else{
              echo "<script>location.href='managerCompany.php';</script>";
              Session::set('msg', '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong>Error !</strong> Company not activated !</div>');
            }
        }


    //managerMaterial.php
    public function selectAllMaterialData(){
      $sql = "SELECT * FROM tbl_rawmaterial ORDER BY id DESC";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->execute();
      return $stmt->fetchAll(PDO::FETCH_OBJ);
    }

    public function addMaterial($data){
      $name = $data['name'];
      $quantity = $data['quantity'];

    
      $sql = "INSERT INTO tbl_rawmaterial(name, quantity) VALUES(:name, :quantity)";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->bindValue(':name', $name);
      $stmt->bindValue(':quantity', $quantity);

      $result = $stmt->execute();
      if ($result) {
        $msg = '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Success !</strong> Wow, you have added Successfully !</div>';
          return $msg;
      }else{
        $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Something went Wrong !</div>';
          return $msg;
      }
    
    
    
    
    
    
    
    }
    

    public function deleteMaterialById($remove){
      $sql = "DELETE FROM tbl_rawmaterial WHERE id = :id";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->bindValue(':id', $remove);
        $result =$stmt->execute();
        if ($result) {
          $msg = '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Success !</strong> Raw Material Deleted Successfully !</div>';
            return $msg;
        }else{
          $msg = '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Data not Deleted !</div>';
            return $msg;
        }
    }

    public function getMaterialInfoById($userid){
      $sql = "SELECT * FROM tbl_rawmaterial WHERE id = :id LIMIT 1";
      $stmt = $this->db->pdo->prepare($sql);
      $stmt->bindValue(':id', $userid);
      $stmt->execute();
      $result = $stmt->fetch(PDO::FETCH_OBJ);
      if ($result) {
        return $result;
      }else{
        return false;
      }


    }

    public function updateMaterialByIdInfo($userid, $data){
      $name = $data['name'];
      $quantity = $data['quantity'];


        $sql = "UPDATE tbl_rawmaterial SET
          name = :name,
          quantity = :quantity
          WHERE id = :id";

          $stmt= $this->db->pdo->prepare($sql);
          $stmt->bindValue(':id', $userid);
          $stmt->bindValue(':name', $name);
          $stmt->bindValue(':quantity', $quantity);
          
          $result =  $stmt->execute();

        if ($result) {
          echo "<script>location.href='managerMaterial.php';</script>";
          Session::set('msg', '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          <strong>Success !</strong> Wow, Material Information updated Successfully !</div>');



        }else{
          echo "<script>location.href='updateMaterial.php';</script>";
          Session::set('msg', '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Error !</strong> Data not inserted !</div>');


        }


      }


    

        // Material Deactivated By Admin
        public function materialDeactiveByAdmin($deactive){
          $sql = "UPDATE tbl_rawmaterial SET
    
           isActive=:isActive
           WHERE id = :id";
    
           $stmt = $this->db->pdo->prepare($sql);
           $stmt->bindValue(':isActive', 1);
           $stmt->bindValue(':id', $deactive);
           $result =   $stmt->execute();
            if ($result) {
              echo "<script>location.href='managerMaterial.php';</script>";
              Session::set('msg', '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <strong>Success !</strong> Materail Diactivated Successfully !</div>');
    
            }else{
              echo "<script>location.href='managerMaterial.php';</script>";
              Session::set('msg', '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong>Error !</strong> Material not Diactivated !</div>');
    
                return $msg;
            }
        }
    
    
        // Reward Activated By Admin
        public function materialActiveByAdmin($active){
          $sql = "UPDATE tbl_rawmaterial SET
           isActive=:isActive
           WHERE id = :id";
    
           $stmt = $this->db->pdo->prepare($sql);
           $stmt->bindValue(':isActive', 0);
           $stmt->bindValue(':id', $active);
           $result =   $stmt->execute();
            if ($result) {
              echo "<script>location.href='managerMaterial.php';</script>";
              Session::set('msg', '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <strong>Success !</strong> Material activated Successfully !</div>');
            }else{
              echo "<script>location.href='managerMaterial.php';</script>";
              Session::set('msg', '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong>Error !</strong> Material not activated !</div>');
            }
        }

        public function updateQuantityByIdInfo($userid, $data){
          $post_id = $data['post_id'];
          $quantity = $data['quantity'];
          $reason = $data['reason'];
          $update_by = $data['update_by'];
    
    
            $sql = "INSERT INTO tbl_reason(post_id, quantity, reason, update_by) VALUES(:post_id, :quantity, :reason, :update_by)";
    
              $stmt= $this->db->pdo->prepare($sql);
              $stmt->bindValue(':post_id', $userid);
              $stmt->bindValue(':quantity', $quantity);
              $stmt->bindValue(':reason', $reason);
              $stmt->bindValue(':update_by', $update_by);
              
              $result =  $stmt->execute();
    
            if ($result) {
              echo "<script>location.href='updateReward.php?id=userid';</script>";
              Session::set('msg', '<div class="alert alert-success alert-dismissible mt-3" id="flash-msg">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <strong>Success !</strong> Wow, Quantity Information updated Successfully !</div>');
    
    
    
            }else{
              echo "<script>location.href='updateQuantity.php';</script>";
              Session::set('msg', '<div class="alert alert-danger alert-dismissible mt-3" id="flash-msg">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong>Error !</strong> Data not inserted !</div>');
    
    
            }
    
    
          }
    
 

}
