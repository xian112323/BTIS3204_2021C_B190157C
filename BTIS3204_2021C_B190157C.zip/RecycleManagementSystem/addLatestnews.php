<?php
include 'inc/header02.php';
$success_message = '';  
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
     $postAdd = $users->addLatestnews($_POST);
  
  }
  if (isset($postAdd)) {
    echo $postAdd;
  }
?>
<!DOCTYPE html>  
<html>  
     <head>  
          <title>Article</title>  

     </head>  
     <body>  
          <br /><br />  
          <div class="container" style="width:700px;">  
               <form method="post">  
                    <label>Article Title</label>  
                    <input type="text" name="post_title" class="form-control" />  
                    <br />  
                    <label>Article Context</label>  
                    <textarea name="post_desc" class="form-control"></textarea>  
                    <br />  
                    <label>Article Category</label><br />
                    <select class="form-control" name="categoryid" id="categoryid">
                    <option value="1" selected='selected'>Latest News</option>
                    <option value="2" >Recycle Materials</option>
                    <option value="3" >Recycle Knowledges</option>
                    <option value="4" >Benefits Of Recycling</option>
                    <!--<input type="radio" name="categoryid" value="1" checked="checked">Latest News<br>
                    <input type="radio" name="categoryid" value="2">Recycle Materials<br>
                    <input type="radio" name="categoryid" value="3">Recycle Knowledges<br>
                    <input type="radio" name="categoryid" value="4">Benefits Of Recycling<br>-->
                    </select>
                    <br />
                    <input type="submit" name="submit" class="btn btn-info" value="Submit" />  
                    <span class="text-success">  
                    <?php  
                    if(isset($success_message))  
                    {  
                         echo $success_message;  
                    }  
                    ?>  
                    </span>  
               </form>  
          </div>  
     </body>  
</html>