<?php
include 'inc/reward.php';
Session::CheckSession();
?>

<?php

if (isset($_GET['id'])) {
  $userid = preg_replace('/[^a-zA-Z0-9-]/', '', (int)$_GET['id']);
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    $updateQuantity = $users->updateQuantityByIdInfo($userid, $_POST);
  
  }
}
  

  if (isset($updateQuantitye)) {
    echo $updateQuantitye;
  }
?>
<!DOCTYPE html>  
<html>  
     <head>  
          <title>Reward Quantity</title>  

     </head>  
     <body>
     <div class="card ">
   <div class="card-header">
          <h3>Reward Info <span class="float-right"> <a href="rewardsystem.php" class="btn btn-primary">Back</a> </h3>
        </div>
        <div class="card-body">
     <?php
    $getUinfo = $users->getRewardInfoById($userid);
    if ($getUinfo) {






     ?>  
          <br /><br />  
          <div class="container" style="width:700px;">  
          <form class="" action="" method="POST">
            <div class="form-group">
                    <label>ID</label>  
                    <input type="text" name="post_id"value="<?php echo $getUinfo->post_id; ?>"readonly class="form-control" />  
                </div> 
                <div class="form-group">
                    <label>Quantity</label>  
                    <input type="text" name="oriquantity"value="<?php echo $getUinfo->post_quantity; ?>"readonly class="form-control" />  
                </div> 
                <div class="form-group">
                    <label>Update Quantity</label>  
                    <input type="text" name="quantity" class="form-control" /> 
                <div class="form-group"> 
                    <label>Reason</label>  
                    <textarea name="reason"  class="form-control"></textarea>  
                </div> 
                <div class="form-group">
                    <label>Update By</label>  
                    <input type="text" name="update_by" class="form-control" />  
                </div> 
                </div> 
                <div class="form-group
              <?php if (Session::get("id") == $getUinfo->id) {
                echo "d-none";
              } ?>
              ">

<div class="form-group">
  <button type="submit" name="update" class="btn btn-success">Update</button>
</div>

               </form>  
          </div> 
          <?php }else{

header('Location:rewardsystem.php');
} ?> 
        </div>
     </div>
     </body>  

<?php
  include 'inc/footer.php';

  ?>
