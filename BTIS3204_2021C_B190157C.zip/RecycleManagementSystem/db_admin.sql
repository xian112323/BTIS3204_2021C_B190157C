-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 27, 2022 at 03:57 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_admin`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` int(11) NOT NULL,
  `role` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `role`) VALUES
(1, 'Latest News'),
(2, 'Recycle Materials'),
(3, 'Recycle Knowledges'),
(4, 'Benefits Of Recycling');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_company`
--

CREATE TABLE `tbl_company` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `email` text NOT NULL,
  `address` text NOT NULL,
  `isActive` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_company`
--

INSERT INTO `tbl_company` (`id`, `name`, `mobile`, `email`, `address`, `isActive`, `created_at`, `updated_at`) VALUES
(1, 'paragon soh', '012337860', 'paragon@paragon.com', 'No 100, jalan sentosa 5/1,\r\ntaman sentosa,\r\n81000 kulai,\r\njohor.', 0, '2021-11-29 04:42:24', '2022-01-24 04:40:58');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_minestone`
--

CREATE TABLE `tbl_minestone` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `points` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_minestone`
--

INSERT INTO `tbl_minestone` (`id`, `name`, `details`, `points`) VALUES
(1, 'Use the app 7 days', 'Login the software and use it at least 7 days', 200);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_posts`
--

CREATE TABLE `tbl_posts` (
  `post_id` int(11) NOT NULL,
  `post_title` varchar(150) NOT NULL,
  `post_desc` text NOT NULL,
  `categoryid` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_posts`
--

INSERT INTO `tbl_posts` (`post_id`, `post_title`, `post_desc`, `categoryid`) VALUES
(5, 'Recycle Materials 01', 'Paper - newspaper, books, magazines', 3),
(8, 'example', 'When creating a radio button form in HTML, the input tag is used and contains the type, name, and value attributes.\r\n\r\n-The type attribute is set to \"Radio\" for Radio buttons\r\n-The name attribute is set to the collective or group name of all the radio buttons. All the radio buttons in a certain group will all have the same name attribute, which in the example above is \"credit_card\".\r\n-The value attribute is set to the name of each indivdual element of the radio buttons. In this case, since we are listing credit cards, the values of the attributes are \"MasterCard\", \"Visa\", and \"American Express\". When displaying the data from a selected radio button, it is the value attribute which is shown.\r\n-If you want to select a radio button by default, usually the first one, you add checked=\"checked\" to the first radio button.\r\n\r\nThe text you place after the input tag is the text that is shown in the radio button options.\r\n\r\nIn order for PHP to extract the data from the HTML form, the following line of code are used.', 2),
(10, 'latest news 02', 'A public enquiry was held at the Office for the Traffic Commissioner (OTC) in Cambridge in July, after residents claimed that the early morning movements of Veolia’s heavy goods vehicle’s (HGVs) were impacting their wellbeing.\r\n\r\nAt the enquiry, Veolia offered to enforce a number of undertakings to reduce the noise coming from the site.\r\n\r\nThe decision following the enquiry, which was handed down last month, determined that the waste management company carry out these undertakings, as well as six other conditions imposed by the Traffic Commissioner.\r\n\r\n‘Good neighbours’\r\nA Veolia spokesperson said: “We always strive to be good neighbours in the communities where we work.\r\n\r\n“We welcome the ruling from the Traffic Commissioner and we are making the changes to minimise any impact from traffic and our operations, including upgrading our vehicles, altering operational times and improving staff training and awareness.”', 1),
(11, 'Latest News 001', 'A public enquiry was held at the Office for the Traffic Commissioner (OTC) in Cambridge in July, after residents claimed that the early morning movements of Veolia’s heavy goods vehicle’s (HGVs) were impacting their wellbeing.\r\n\r\nAt the enquiry, Veolia offered to enforce a number of undertakings to reduce the noise coming from the site.\r\n\r\nThe decision following the enquiry, which was handed down last month, determined that the waste management company carry out these undertakings, as well as six other conditions imposed by the Traffic Commissioner.\r\n\r\n‘Good neighbours’\r\nA Veolia spokesperson said: “We always strive to be good neighbours in the communities where we work.\r\n\r\n“We welcome the ruling from the Traffic Commissioner and we are making the changes to minimise any impact from traffic and our operations, including upgrading our vehicles, altering operational times and improving staff training and awareness.”', 1),
(13, 'Latest News 10', 'Recycling is the process of converting waste materials into new materials and objects. The recovery of energy from waste materials is often included in this concept. The recyclability of a material depends on its ability to reacquire the properties it had in its original state.[1] It is an alternative to \"conventional\" waste disposal that can save material and help lower greenhouse gas emissions. It can also prevent the waste of potentially useful materials and reduce the consumption of fresh raw materials, reducing energy use, air pollution (from incineration) and water pollution (from landfilling).\r\n\r\nRecycling is a key component of modern waste reduction and is the third component of the \"Reduce, Reuse, and Recycle\" waste hierarchy.[2][3] It promotes environmental sustainability by removing raw material input and redirecting waste output in the economic system.[4] There are some ISO standards related to recycling, such as ISO 15270:2008 for plastics waste and ISO 14001:2015 for environmental management control of recycling practice.\r\n\r\nRecyclable materials include many kinds of glass, paper, cardboard, metal, plastic, tires, textiles, batteries, and electronics. The composting and other reuse of biodegradable waste—such as food and garden waste—is also a form of recycling.[5] Materials for recycling are either delivered to a household recycling center or picked up from curbside bins, then sorted, cleaned, and reprocessed into new materials for manufacturing new products.\r\n\r\nIn ideal implementations, recycling a material produces a fresh supply of the same material—for example, used office paper would be converted into new office paper, and used polystyrene foam into new polystyrene. Some types of materials, such as metal cans, can be remanufactured repeatedly without losing their purity.[6] With other materials, this is often difficult or too expensive (compared with producing the same product from raw materials or other sources), so \"recycling\" of many products and materials involves their reuse in producing different materials (for example, paperboard). Another form of recycling is the salvage of constituent materials from complex products, due to either their intrinsic value (such as lead from car batteries and gold from printed circuit boards), or their hazardous nature (e.g. removal and reuse of mercury from thermometers and thermostats).', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `Name` varchar(50) NOT NULL,
  `Prix` int(11) NOT NULL,
  `Categorie` varchar(50) NOT NULL,
  `etat` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_rawmaterial`
--

CREATE TABLE `tbl_rawmaterial` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `quantity` int(10) NOT NULL,
  `isActive` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_rawmaterial`
--

INSERT INTO `tbl_rawmaterial` (`id`, `name`, `quantity`, `isActive`, `created_at`, `updated_at`) VALUES
(1, 'Paper', 1000, 0, '2021-11-29 05:11:01', '2021-11-29 05:14:05'),
(3, 'Rigid Plastic / Bottles', 1000, 0, '2022-01-23 07:42:35', '2022-01-23 07:42:35'),
(4, 'Metals', 1000, 0, '2022-01-23 07:42:40', '2022-01-23 07:42:40'),
(5, 'Glass', 1000, 0, '2022-01-23 07:42:45', '2022-01-23 07:42:45'),
(6, 'Electronic Items (E-Waste)', 1000, 0, '2022-01-23 07:42:55', '2022-01-23 07:43:44');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_reason`
--

CREATE TABLE `tbl_reason` (
  `id` int(11) NOT NULL,
  `post_id` int(10) NOT NULL,
  `quantity` int(10) NOT NULL,
  `reason` text NOT NULL,
  `update_by` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_reason`
--

INSERT INTO `tbl_reason` (`id`, `post_id`, `quantity`, `reason`, `update_by`, `created_at`) VALUES
(1, 11, 1000, 'add', 'xian', '2022-01-24 00:00:00'),
(2, 11, 1000, 'asds', 'xian', '2022-01-24 00:00:00'),
(3, 11, 0, '', '', '2022-01-24 00:00:00'),
(4, 11, 0, '', '', '2022-01-24 00:00:00'),
(5, 11, 0, '', '', '2022-01-24 00:00:00'),
(6, 11, 1000, 'adsafs', 'xian', '2022-01-24 00:00:00'),
(7, 11, 1000, '', 'xian', '2022-01-24 10:32:53'),
(8, 11, 100, 'dfjkggjl;kl\'j', 'xian', '2022-01-24 12:39:47'),
(9, 11, 100, 'add', 'xian', '2022-01-24 13:15:31');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_reward`
--

CREATE TABLE `tbl_reward` (
  `post_id` int(10) NOT NULL,
  `post_name` varchar(100) NOT NULL,
  `post_image` text NOT NULL,
  `post_quantity` int(6) NOT NULL,
  `post_point` int(10) NOT NULL,
  `isActive` tinyint(4) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_reward`
--

INSERT INTO `tbl_reward` (`post_id`, `post_name`, `post_image`, `post_quantity`, `post_point`, `isActive`) VALUES
(7, 'Thermos bottle', 'thermos.png', 100, 50000, 0),
(8, 'A4 paper', 'a4paper.png', 100, 10000, 0),
(11, 'High Quality Plastic Water bottle', 'plasticbottle.jpg', 100, 25000, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_roles`
--

CREATE TABLE `tbl_roles` (
  `id` int(11) NOT NULL COMMENT 'role_id',
  `role` varchar(255) DEFAULT NULL COMMENT 'role_text'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_roles`
--

INSERT INTO `tbl_roles` (`id`, `role`) VALUES
(1, 'Admin'),
(2, 'Editor'),
(3, 'User');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_rules`
--

CREATE TABLE `tbl_rules` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `details` text NOT NULL,
  `points` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_rules`
--

INSERT INTO `tbl_rules` (`id`, `name`, `details`, `points`) VALUES
(3, 'Glass', 'Food containers or jars, soft drink and beer bottles, wine and liquor bottles', 120),
(6, 'Metals', 'Tin, aluminum, and steel cans', 100),
(7, 'Rigid Plastic / Bottles', 'Any plastic bottles or containers found in your kitchen', 70),
(8, 'Paper', 'newspaper, book, paper box, etc', 50),
(9, 'Electronic Items (E-Waste)', 'Smartphones, Desktop Computers, Computer Monitors, Laptops and etc.', 150);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_task`
--

CREATE TABLE `tbl_task` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `points` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_task`
--

INSERT INTO `tbl_task` (`id`, `name`, `details`, `points`) VALUES
(4, 'Visit 10s', 'visit recycling information system at least 10 second', 100);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `address` text DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `points` int(10) NOT NULL DEFAULT 1000
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `email`, `phone`, `address`, `password`, `points`) VALUES
(1, 'user10', 'user1@gmail.com', '0123344556', NULL, 'user10', 1000),
(2, 'user11', 'user11@gmail.com', '0123344546', NULL, 'user11', 1000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `mobile` varchar(25) DEFAULT NULL,
  `roleid` tinyint(4) DEFAULT NULL,
  `isActive` tinyint(4) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `name`, `username`, `email`, `password`, `mobile`, `roleid`, `isActive`, `created_at`, `updated_at`) VALUES
(29, 'admin02', 'admin02', 'admin02@admin.com', 'd5f3f4db6d8400f894bde2523e8247b9ff2346fb', '1122334455', 1, 0, '2021-09-10 05:38:17', '2022-01-24 04:37:03'),
(31, 'admin03', 'admin03', 'admin03@admin.com', 'c92a181ed4f11700ac71a45e219647fcaa5077ab', '0122255664', 1, 0, '2022-01-14 12:43:00', '2022-01-24 05:13:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_company`
--
ALTER TABLE `tbl_company`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_minestone`
--
ALTER TABLE `tbl_minestone`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_posts`
--
ALTER TABLE `tbl_posts`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `tbl_rawmaterial`
--
ALTER TABLE `tbl_rawmaterial`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_reason`
--
ALTER TABLE `tbl_reason`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_reward`
--
ALTER TABLE `tbl_reward`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `tbl_roles`
--
ALTER TABLE `tbl_roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_rules`
--
ALTER TABLE `tbl_rules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_task`
--
ALTER TABLE `tbl_task`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_company`
--
ALTER TABLE `tbl_company`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_minestone`
--
ALTER TABLE `tbl_minestone`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_posts`
--
ALTER TABLE `tbl_posts`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_rawmaterial`
--
ALTER TABLE `tbl_rawmaterial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_reason`
--
ALTER TABLE `tbl_reason`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_reward`
--
ALTER TABLE `tbl_reward`
  MODIFY `post_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_roles`
--
ALTER TABLE `tbl_roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'role_id', AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_rules`
--
ALTER TABLE `tbl_rules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_task`
--
ALTER TABLE `tbl_task`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
