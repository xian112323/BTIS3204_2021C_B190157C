<?php
include 'inc/header02.php';
Session::CheckSession();
?>

<?php

if (isset($_GET['id'])) {
  $userid = preg_replace('/[^a-zA-Z0-9-]/', '', (int)$_GET['id']);

}
$success_message = '';  
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    $updateArticle = $users->updateArticleByIdInfo($userid, $_POST);
  
  }
  if (isset($updateArticle)) {
    echo $updateArticle;
  }
?>
<!DOCTYPE html>  
<html>  
     <head>  
          <title>Article</title>  

     </head>  
     <body>
     <div class="card ">
   <div class="card-header">
          <h3>Article Info <span class="float-right"> <a href="recycleInformationsystem.php" class="btn btn-primary">Back</a> </h3>
        </div>
        <div class="card-body">
     <?php
    $getUinfo = $users->getArticleInfoById($userid);
    if ($getUinfo) {






     ?>  
          <br /><br />  
          <div class="container" style="width:700px;">  
               <form method="post">  
                    <label>Article Title</label>  
                    <input type="text" name="post_title"value="<?php echo $getUinfo->post_title; ?>" class="form-control" />  
                    <br />  
                    <label>Article Context</label>  
                    <textarea name="post_desc"  class="form-control"><?php echo $getUinfo->post_desc; ?></textarea>  
                    <br />  
                    <!--<label>Article Category</label><br />-->
                    <div class="form-group">
                  <label for="sel1">Article Category</label>
                  <select class="form-control" name="categoryid" id="categoryid">

                  <?php

                if($getUinfo->categoryid == '1'){?>
                    <option value="1" selected='selected'>Latest News</option>
                    <option value="2" >Recycle Materials</option>
                    <option value="3" >Recycle Knowledges</option>
                    <option value="4" >Benefits Of Recycling</option>
                <?php }elseif($getUinfo->categoryid == '2'){?>
                    <option value="1" >Latest News</option>
                    <option value="2" selected='selected'>Recycle Materials</option>
                    <option value="3" >Recycle Knowledges</option>
                    <option value="4" >Benefits Of Recycling</option>
                <?php }elseif($getUinfo->categoryid == '3'){?>
                    <option value="1" >Latest News</option>
                    <option value="2" >Recycle Materials</option>
                    <option value="3" selected='selected'>Recycle Knowledges</option>
                    <option value="4" >Benefits Of Recycling</option>
                <?php }elseif($getUinfo->categoryid == '4'){?>
                    <option value="1" >Latest News</option>
                    <option value="2" >Recycle Materials</option>
                    <option value="3" >Recycle Knowledges</option>
                    <option value="4" selected='selected'>Benefits Of Recycling</option>

                <?php } ?>


                  </select>
                </div>
                <div class="form-group
              <?php if (Session::get("post_id") == $getUinfo->post_id) {
                
              } ?>
              ">
                </div>
                    <br />
                    <input type="submit" name="update" class="btn btn-info" value="Update" />  
                    <span class="text-success">  
                    <?php  
                    if(isset($success_message))  
                    {  
                         echo $success_message;  
                    }  
                    ?>  
                    </span>  
               </form>  
          </div> 
          <?php }else{

header('Location:recycleInformationsystem.php');
} ?> 
        </div>
     </div>
     </body>  
</html>