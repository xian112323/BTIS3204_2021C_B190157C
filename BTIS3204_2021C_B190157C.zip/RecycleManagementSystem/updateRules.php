<?php
include 'inc/rules.php';
Session::CheckSession();
?>

<?php

if (isset($_GET['id'])) {
  $userid = preg_replace('/[^a-zA-Z0-9-]/', '', (int)$_GET['id']);

}
$success_message = '';  
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    $updateRules = $users->updateRulesByIdInfo($userid, $_POST);
  
  }
  if (isset($updateRules)) {
    echo $updateRules;
  }
?>
<!DOCTYPE html>  
<html>  
     <head>  
          <title>Rules</title>  

     </head>  
     <body>
     <div class="card ">
   <div class="card-header">
          <h3>Rules Info <span class="float-right"> <a href="rulessystem.php" class="btn btn-primary">Back</a> </h3>
        </div>
        <div class="card-body">
     <?php
    $getUinfo = $users->getRulesInfoById($userid);
    if ($getUinfo) {






     ?>  
          <br /><br />  
          <div class="container" style="width:700px;">  
          <form class="" action="" method="POST">
                <div class="form-group">
                    <label>Material Name</label>  
                    <input type="text" name="name"value="<?php echo $getUinfo->name; ?>" class="form-control" />  
                </div> 
                <div class="form-group"> 
                    <label>Details</label>  
                    <textarea name="details"  class="form-control"><?php echo $getUinfo->details; ?></textarea>  
                </div> 
                <div class="form-group">
                    <label>Point</label>  
                    <input type="text" name="points"value="<?php echo $getUinfo->points; ?>" class="form-control" />  
                </div> 

                <div class="form-group
              <?php if (Session::get("id") == $getUinfo->id) {
                echo "d-none";
              } ?>
              ">

<div class="form-group">
  <button type="submit" name="update" class="btn btn-success">Update</button>
</div>

               </form>  
          </div> 
          <?php }else{

header('Location:rulessystem.php');
} ?> 
        </div>
     </div>
     </body>  

<?php
  include 'inc/footer.php';

  ?>
