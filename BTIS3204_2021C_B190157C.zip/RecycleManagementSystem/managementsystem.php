<?php
include 'inc/management.php';

Session::CheckSession();

?>
<style>
.speciality .box-container{
  display: flex;
  flex-wrap: wrap;
  gap:1.5rem;
}

.speciality .box-container .box{
  flex:1 1 30rem;
  position: relative;
  overflow: hidden;
  box-shadow: 0 .5rem 1rem rgba(0,0,0,.1);
  border:.1rem solid rgba(0,0,0,.3);
  cursor: pointer;
  border-radius: .5rem;
}

.speciality .box-container .box .image{
  height:100%;
  width:100%;
  object-fit: cover;
  position: absolute;
  top:-100%; left:0%;
}

.speciality .box-container .box .content{
  text-align: center;
  background:#fff;
  padding:2rem;
}

.speciality .box-container .box .content img{
  margin:1.5rem 0;
}

.speciality .box-container .box .content h3{
  font-size: 2.5rem;
  color:#333;
}

.speciality .box-container .box .content p{
  font-size: 1.6rem;
  color:#666;
  padding:1rem 0;
}

.speciality .box-container .box:hover .image{
  top:0;
}

.speciality .box-container .box:hover .content{
  transform: translateY(100%);
}
</style>
<!--<div class="card">
  <div class="container">
  
<a class="btn btn-primary" href="index01.php">Admin Management System</a>
  </div>
 
</div>
<div class="container">

  <div>
<a class="btn btn-primary" href="recycleInformationsystem.php">Recycle Information System</a>
  </div>

  <div>
<a class="btn btn-primary" href="rewardsystem.php">Reward System</a>
  </div>


<div>
<a class="btn btn-primary" href="pointsystem.php">Point System</a>
  </div>

</div>
</div>-->
		<!-- SECTION -->
        <section class="speciality" id="speciality">

<br>
		<div class="box-container">

        <div class="box" >
        <a href="managerCompany.php"><img class="image" src="./image/company.png" alt=""></a>
            <div class="content">
                <img src="./image/company.png" alt="">
                <h3>Cooperative Company</h3>
            </div>
        </div>
        <div class="box">
        <a href="managerMaterial.php"><img class="image" src="./image/raw.png" alt="">
            <div class="content">
                <img src="./image/raw.png" alt="">
                <h3>Raw Material</h3>
            </div>
        </div>
      
							
<?php


  include 'inc/footer.php';

  ?>
