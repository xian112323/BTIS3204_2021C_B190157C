<?php
include 'inc/rawmaterial.php';
Session::CheckSession();
?>

<?php

if (isset($_GET['id'])) {
  $userid = preg_replace('/[^a-zA-Z0-9-]/', '', (int)$_GET['id']);
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    $updateMaterial = $users->updateMaterialByIdInfo($userid, $_POST);
  
  }
}


  if (isset($updateMaterial)) {
    echo $updateMaterial;
  }
?>
<!DOCTYPE html>  
<html>  
     <head>  
          <title>Raw Material</title>  

     </head>  
     <body>
     <div class="card ">
   <div class="card-header">
          <h3>Raw Material Info <span class="float-right"> <a href="managerMaterial.php" class="btn btn-primary">Back</a> </h3>
        </div>
        <div class="card-body">
     <?php
    $getUinfo = $users->getMaterialInfoById($userid);
    if ($getUinfo) {






     ?>  
          <br /><br />  
          <div class="container" style="width:700px;">  
          <form class="" action="" method="POST">
                <div class="form-group">
                    <label>Material Name</label>  
                    <input type="text" name="name"value="<?php echo $getUinfo->name; ?>" class="form-control" />  
                </div> 
                <div class="form-group">
                    <label>Quantity</label>  
                    <input type="text" name="oquantity"value="<?php echo $getUinfo->quantity; ?>"readonly class="form-control" />  
                </div> 
                <div class="form-group">
                    <label>Add Quantity</label>  
                    <input type="text" name="quantity" class="form-control" /> 
                    
                     
                </div> 


                <div class="form-group
              <?php if (Session::get("id") == $getUinfo->id) {
                echo "d-none";
              } ?>
              ">

<div class="form-group">
  <button type="submit" name="update" class="btn btn-success">Update</button>
</div>

               </form>  
          </div> 
          <?php }else{

header('Location:managerMaterial.php');
} ?> 
        </div>
     </div>
     </body>  

<?php
  include 'inc/footer.php';

  ?>
