<?php
include 'inc/rawmaterial.php';
$success_message = '';  
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
     $postAdd = $users->addMaterial($_POST);
  
  }
  if (isset($postAdd)) {
    echo $postAdd;
  }
?>
<!DOCTYPE html>  
<html>  
     <head>  
          <title>Material</title>  

     </head>  
     <body>  
          <br /><br />  
          <div class="container" style="width:700px;">  
               <form method="post">  
                    <label>Material Name</label>  
                    <input type="text" name="name" class="form-control" />  
                    <br />  
                    <label>Quantity</label><br />
                    <input type="text" name="quantity" class="form-control" />  
                    <br />  
                    <input type="submit" name="submit" class="btn btn-info" value="Submit" />  
                    <span class="text-success">  
                    <?php  
                    if(isset($success_message))  
                    {  
                         echo $success_message;  
                    }  
                    ?>  
                    </span>  
               </form>  
          </div>  
     </body>  
</html>