<?php
include 'inc/reward.php';
$success_message = '';  
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
     $rewardAdd = $users->addReward($_POST);
  
  }
  if (isset($rewardAdd)) {
    echo $rewardAdd;
  }
?>
<!DOCTYPE html>  
<html>  
     <head>  
          <title>Reward</title>  

     </head>  
     <body>  
          <br /><br />  
          <div class="container" style="width:700px;">  
               <form method="post" action="" enctype="multipart/form-data">  
                    <label>Reward Name</label>  
                    <input type="text" name="post_name" class="form-control" />  
                    <br />  
                    <div class="col-md-4">
                      <div class="">
                        <label for="">Add Image</label>
                        <input type="file" name="post_image" required class="btn btn-fill btn-success" >
                      </div>
                    </div>
                    <label>Quantity</label>  
                    <input type="text" name="post_quantity" class="form-control" />  
                    <br />  
                    <label>Point</label>  
                    <input type="text" name="post_point" class="form-control" />  
                    <br />  

                    <input type="submit" name="submit" class="btn btn-info" value="Submit" />  
                    <span class="text-success">  
                    <?php  
                    if(isset($success_message))  
                    {  
                         echo $success_message;  
                    }  
                    ?>  
                    </span>  
               </form>  
          </div>  
     </body>  
</html>