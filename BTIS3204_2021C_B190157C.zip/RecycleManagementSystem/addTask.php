<?php
include 'inc/task.php';
$success_message = '';  
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
     $postAdd = $users->addTask($_POST);
  
  }
  if (isset($postAdd)) {
    echo $postAdd;
  }
?>
<!DOCTYPE html>  
<html>  
     <head>  
          <title>Task</title>  

     </head>  
     <body>  
          <br /><br />  
          <div class="container" style="width:700px;">  
               <form method="post">  
                    <label>Task Name</label>  
                    <input type="text" name="name" class="form-control" />  
                    <br />  
                    <label>Details</label>  
                    <textarea name="details" class="form-control"></textarea>  
                    <br />  
                    <label>Points</label><br />
                    <input type="text" name="points" class="form-control" />  
                    </select>
                    <br />
                    <input type="submit" name="submit" class="btn btn-info" value="Submit" />  
                    <span class="text-success">  
                    <?php  
                    if(isset($success_message))  
                    {  
                         echo $success_message;  
                    }  
                    ?>  
                    </span>  
               </form>  
          </div>  
     </body>  
</html>