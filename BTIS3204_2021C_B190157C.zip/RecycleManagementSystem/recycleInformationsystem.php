<?php
include 'inc/header02.php';

Session::CheckSession();

$logMsg = Session::get('logMsg');
if (isset($logMsg)) {
  echo $logMsg;
}
$msg = Session::get('msg');
if (isset($msg)) {
  echo $msg;
}
Session::set("msg", NULL);
Session::set("logMsg", NULL);
?>
<?php

if (isset($_GET['remove'])) {
  $remove = preg_replace('/[^a-zA-Z0-9-]/', '', (int)$_GET['remove']);
  $removeUser = $users->deleteArticleById($remove);
}

if (isset($removeUser)) {
  echo $removeUser;
}
if (isset($_GET['deactive'])) {
  $deactive = preg_replace('/[^a-zA-Z0-9-]/', '', (int)$_GET['deactive']);
  $deactiveId = $users->userDeactiveByAdmin($deactive);
}

if (isset($deactiveId)) {
  echo $deactiveId;
}
if (isset($_GET['active'])) {
  $active = preg_replace('/[^a-zA-Z0-9-]/', '', (int)$_GET['active']);
  $activeId = $users->userActiveByAdmin($active);
}

if (isset($activeId)) {
  echo $activeId;
}


 ?>
      <div class="card ">
        <div class="card-header">
          <h3><i class="fas fa-newspaper mr-2"></i>Article list <span class="float-right">Welcome! <strong>
            <span class="badge badge-lg badge-secondary text-white">
<?php
$username = Session::get('username');
if (isset($username)) {
  echo $username;
}
 ?></span>

          </strong></span></h3>
        </div>
        <div class="card-body pr-2 pl-2">

          <table id="example" class="table table-striped table-bordered" style="width:100%">
                  <thead>
                    <tr>
                      <th  class="text-center">No</th>
                      <th  class="text-center">Title</th>
                      <th  class="text-center">Context</th>
                      <th  class="text-center">Category</th>
                      <th  width='25%' class="text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php

                      $allUser = $users->selectAllArticleData();

                      if ($allUser) {
                        $i = 0;
                        foreach ($allUser as  $value) {
                          $i++;

                     ?>

                        <tr class="text-center"
                        <?php if (Session::get("id") == $value->categoryid) {
                        echo "style='background:#d9edf7' ";
                        } ?>
                        >


                        <td><?php echo $i; ?></td>
                        <td><?php echo $value->post_title; ?></td>
                        <td><?php echo $value->post_desc; ?> <br></td>
                        <td><?php echo $value->categoryid; ?> <br>
                        <?php if ($value->categoryid  == '1'){
                          echo "<span class='badge badge-lg badge-warning text-white'>Latest News</span>";
                        } elseif ($value->categoryid == '2') {
                          echo "<span class='badge badge-lg badge-warning text-white'>Recycle Materials</span>";
                        }elseif ($value->categoryid == '3') {
                            echo "<span class='badge badge-lg badge-warning text-white'>Recycle Knowledges</span>";
                        }elseif ($value->categoryid == '4') {
                            echo "<span class='badge badge-lg badge-warning text-white'>Benefits Of Recycling</span>";
                        }?></td>


                        <td>
                          <?php if ( Session::get("roleid") == '1') {?>
                            <a class="btn btn-success btn-sm
                            " href="updateArticle.php?id=<?php echo $value->post_id;?>">View</a>
                            <a class="btn btn-info btn-sm " href="updateArticle.php?id=<?php echo $value->post_id;?>">Edit</a>
                            <a onclick="return confirm('Are you sure To Delete ?')" class="btn btn-danger
                    <?php if (Session::get("id") == $value->id) {
                      echo "disabled";
                    } ?>
                             btn-sm " href="?remove=<?php echo $value->post_id;?>">Remove</a>



                        
                        <?php } ?>

                        

                        </td>
                      </tr>
                    <?php }}?>

                    

                  </tbody>

              </table>









        </div>
      </div>



  <?php
  include 'inc/footer.php';

  ?>