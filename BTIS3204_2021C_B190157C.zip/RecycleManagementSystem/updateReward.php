<?php
include 'inc/reward.php';
Session::CheckSession();
?>

<?php

if (isset($_GET['id'])) {
  $userid = preg_replace('/[^a-zA-Z0-9-]/', '', (int)$_GET['id']);

}
$success_message = '';  
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['updateReward'])) {
    $updateReward = $users->updateRewardByIdInfo($userid, $_POST);
  
  }
  if (isset($updateReward)) {
    echo $updateReward;
  }
?>
<!DOCTYPE html>  
<html>  
     <head>  
          <title>Reward</title>  

     </head>  
     <body>
     <div class="card ">
   <div class="card-header">
          <h3>Reward Info <span class="float-right"> <a href="rewardsystem.php" class="btn btn-primary">Back</a> </h3>
        </div>
        <div class="card-body">
     <?php
    $getUinfo = $users->getRewardInfoById($userid);
    if ($getUinfo) {






     ?>  
          <br /><br />  
          <div class="container" style="width:700px;">  
               <form method="post" action="" enctype="multipart/form-data">  
                    <label>Reward Name</label>  
                    <input type="text" name="post_name"value="<?php echo $getUinfo->post_name; ?>" class="form-control" />  
                    <br />  
                    <div class="col-md-4">
                      <div class="">
                        <label for="">Add Image<?php echo "<img src='product_images/$getUinfo->post_image' style='width:150px; height:150px; border:groove #000'>"; ?></label> 
                        <input type="file" name="post_image" >
                    </div>
                    </div>
                    <label>Quantity</label>  
                    <input type="text" name="post_quantity"value="<?php echo $getUinfo->post_quantity; ?>"readonly class="form-control" />  
                    <br />
                    <a class="btn btn-info btn-sm " href="updateQuantity.php?id=<?php echo $getUinfo->post_id;?>">Update Quantity</a>
                    <br />  
                    <label>Point</label>  
                    <input type="text" name="post_point"value="<?php echo $getUinfo->post_point; ?>" class="form-control" />  
                    <br />  

                    <input type="submit" name="updateReward" class="btn btn-info" value="Update" />  
                    <span class="text-success">  
                    <?php  
                    if(isset($success_message))  
                    {  
                         echo $success_message;  
                    }  
                    ?>  
                    </span>  
               </form>  
          </div> 
          <?php }else{

header('Location:rewardsystem.php');
} ?> 
        </div>
     </div>
     </body>  
</html>