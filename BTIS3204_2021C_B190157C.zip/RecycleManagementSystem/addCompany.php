<?php
include 'inc/company.php';
$success_message = '';  
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
     $postAdd = $users->addCompany($_POST);
  
  }
  if (isset($postAdd)) {
    echo $postAdd;
  }
?>
<!DOCTYPE html>  
<html>  
     <head>  
          <title>Company</title>  

     </head>  
     <body>  
          <br /><br />  
          <div class="container" style="width:700px;">  
               <form method="post">  
                    <label>Company Name</label>  
                    <input type="text" name="name" class="form-control" />  
                    <br />  
                    <label>Email</label><br />
                    <input type="text" name="email" class="form-control" />  
                    <br /> 
                    <label>Contact No</label><br />
                    <input type="text" name="mobile" class="form-control" />  
                    <br />
                    <label>Address</label>  
                    <textarea name="address" class="form-control"></textarea>  
                    <br /> 
                    <input type="submit" name="submit" class="btn btn-info" value="Submit" />  
                    <span class="text-success">  
                    <?php  
                    if(isset($success_message))  
                    {  
                         echo $success_message;  
                    }  
                    ?>  
                    </span>  
               </form>  
          </div>  
     </body>  
</html>